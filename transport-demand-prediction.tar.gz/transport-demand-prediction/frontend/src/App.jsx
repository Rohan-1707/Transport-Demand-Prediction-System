/**
 * App.jsx — root component
 */
import Dashboard from "./pages/Dashboard";

export default function App() {
  return <Dashboard />;
}

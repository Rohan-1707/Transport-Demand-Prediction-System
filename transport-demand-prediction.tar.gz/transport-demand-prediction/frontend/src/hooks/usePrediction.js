/**
 * hooks/usePrediction.js
 * ----------------------
 * Custom hook encapsulating prediction state and API call.
 * Components only call `predict(formData)` and read the returned state.
 */

import { useState, useCallback } from "react";
import { predictDemand } from "../services/api";

export function usePrediction() {
  const [prediction, setPrediction] = useState(null);
  const [isLoading,  setIsLoading]  = useState(false);
  const [error,      setError]      = useState(null);

  const predict = useCallback(async (formData) => {
    setIsLoading(true);
    setError(null);
    setPrediction(null);

    try {
      const result = await predictDemand(formData);
      setPrediction(result);
    } catch (err) {
      setError(err.message || "Prediction failed. Is the backend running?");
    } finally {
      setIsLoading(false);
    }
  }, []);

  const reset = useCallback(() => {
    setPrediction(null);
    setError(null);
  }, []);

  return { prediction, isLoading, error, predict, reset };
}

/**
 * components/PredictionForm.jsx
 * ------------------------------
 * Input form for all prediction parameters.
 * Validates locally before submitting to the backend.
 */

import { useState } from "react";

const LOCATIONS = [
  { value: "downtown",      label: "🏙️ Downtown" },
  { value: "suburb",        label: "🏘️ Suburb" },
  { value: "airport",       label: "✈️ Airport" },
  { value: "university",    label: "🎓 University" },
  { value: "shopping_mall", label: "🛍️ Shopping Mall" },
];

const WEATHER_OPTIONS = [
  { value: "sunny",  label: "☀️ Sunny" },
  { value: "cloudy", label: "☁️ Cloudy" },
  { value: "rainy",  label: "🌧️ Rainy" },
  { value: "snowy",  label: "❄️ Snowy" },
  { value: "windy",  label: "💨 Windy" },
];

const MODEL_OPTIONS = [
  { value: "random_forest",     label: "🌲 Random Forest (recommended)" },
  { value: "linear_regression", label: "📈 Linear Regression" },
];

/** A labelled form field wrapper */
function Field({ label, hint, children }) {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-700 mb-1">
        {label}
        {hint && <span className="ml-1 text-slate-400 font-normal text-xs">{hint}</span>}
      </label>
      {children}
    </div>
  );
}

const inputClass =
  "w-full px-3 py-2.5 text-sm border border-slate-200 rounded-xl bg-white text-slate-800 " +
  "focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:border-transparent " +
  "placeholder:text-slate-400 transition";

const today = new Date().toISOString().split("T")[0];

export default function PredictionForm({ onSubmit, isLoading }) {
  const [form, setForm] = useState({
    date:          today,
    hour:          "8",
    location:      "downtown",
    weather:       "sunny",
    temperature_c: "20",
    model_type:    "random_forest",
  });

  const [errors, setErrors] = useState({});

  function set(key, value) {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  }

  function validate() {
    const errs = {};
    if (!form.date)      errs.date = "Date is required";
    const h = parseInt(form.hour, 10);
    if (isNaN(h) || h < 0 || h > 23) errs.hour = "Hour must be 0–23";
    if (!form.location)  errs.location = "Select a location";
    return errs;
  }

  function handleSubmit(e) {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }

    onSubmit({
      date:          form.date,
      hour:          parseInt(form.hour, 10),
      location:      form.location,
      weather:       form.weather,
      temperature_c: parseFloat(form.temperature_c) || 20,
      model_type:    form.model_type,
    });
  }

  const hourValue  = parseInt(form.hour, 10) || 0;
  const ampmLabel  = hourValue < 12 ? `${hourValue || 12}:00 AM` : `${hourValue === 12 ? 12 : hourValue - 12}:00 PM`;

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* Date + Hour */}
      <div className="grid grid-cols-2 gap-4">
        <Field label="Date" hint="(required)">
          <input
            type="date"
            value={form.date}
            max="2030-12-31"
            onChange={(e) => set("date", e.target.value)}
            className={`${inputClass} ${errors.date ? "border-red-300 ring-1 ring-red-300" : ""}`}
          />
          {errors.date && <p className="text-xs text-red-500 mt-1">{errors.date}</p>}
        </Field>

        <Field label="Hour" hint="0–23">
          <input
            type="number"
            min="0" max="23"
            value={form.hour}
            onChange={(e) => set("hour", e.target.value)}
            className={`${inputClass} ${errors.hour ? "border-red-300 ring-1 ring-red-300" : ""}`}
            placeholder="e.g. 8"
          />
          <p className="text-xs text-slate-400 mt-1">{ampmLabel}</p>
          {errors.hour && <p className="text-xs text-red-500 mt-1">{errors.hour}</p>}
        </Field>
      </div>

      {/* Location */}
      <Field label="Location" hint="(required)">
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
          {LOCATIONS.map((loc) => (
            <label key={loc.value}
              className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl border cursor-pointer text-sm transition
                ${form.location === loc.value
                  ? "border-indigo-400 bg-indigo-50 text-indigo-700 font-medium"
                  : "border-slate-200 bg-white text-slate-700 hover:border-slate-300"
                }`}
            >
              <input
                type="radio"
                name="location"
                value={loc.value}
                checked={form.location === loc.value}
                onChange={() => set("location", loc.value)}
                className="sr-only"
              />
              {loc.label}
            </label>
          ))}
        </div>
      </Field>

      {/* Weather + Temperature */}
      <div className="grid grid-cols-2 gap-4">
        <Field label="Weather">
          <select
            value={form.weather}
            onChange={(e) => set("weather", e.target.value)}
            className={inputClass}
          >
            {WEATHER_OPTIONS.map((w) => (
              <option key={w.value} value={w.value}>{w.label}</option>
            ))}
          </select>
        </Field>

        <Field label="Temperature" hint="(°C, optional)">
          <input
            type="number"
            min="-20" max="50" step="0.5"
            value={form.temperature_c}
            onChange={(e) => set("temperature_c", e.target.value)}
            className={inputClass}
            placeholder="20"
          />
        </Field>
      </div>

      {/* Model selector */}
      <Field label="ML Model">
        <div className="flex gap-2">
          {MODEL_OPTIONS.map((m) => (
            <label key={m.value}
              className={`flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl border cursor-pointer text-sm transition text-center
                ${form.model_type === m.value
                  ? "border-violet-400 bg-violet-50 text-violet-700 font-medium"
                  : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"
                }`}
            >
              <input
                type="radio"
                name="model_type"
                value={m.value}
                checked={form.model_type === m.value}
                onChange={() => set("model_type", m.value)}
                className="sr-only"
              />
              {m.label}
            </label>
          ))}
        </div>
      </Field>

      {/* Submit */}
      <button
        type="submit"
        disabled={isLoading}
        className="w-full py-3 px-6 bg-gradient-to-r from-indigo-600 to-violet-600
          text-white font-semibold rounded-xl shadow-sm
          hover:from-indigo-700 hover:to-violet-700
          disabled:opacity-60 disabled:cursor-not-allowed
          transition-all duration-200 text-sm"
      >
        {isLoading ? (
          <span className="flex items-center justify-center gap-2">
            <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
            Predicting…
          </span>
        ) : (
          "🔮 Predict Demand"
        )}
      </button>
    </form>
  );
}

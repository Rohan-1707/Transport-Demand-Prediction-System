/**
 * components/ui.jsx
 * -----------------
 * Shared, reusable UI primitives.
 */

/** Spinning loader with optional label */
export function LoadingSpinner({ label = "Loading…" }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-8">
      <div className="w-10 h-10 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin" />
      <p className="text-sm text-slate-500">{label}</p>
    </div>
  );
}

/** Red error callout */
export function ErrorAlert({ message, onDismiss }) {
  return (
    <div className="flex items-start gap-3 bg-red-50 border border-red-200 rounded-xl p-4">
      <span className="text-red-500 text-lg mt-0.5">⚠</span>
      <div className="flex-1">
        <p className="text-sm font-medium text-red-700">Error</p>
        <p className="text-sm text-red-600 mt-0.5">{message}</p>
      </div>
      {onDismiss && (
        <button
          onClick={onDismiss}
          className="text-red-400 hover:text-red-600 text-lg leading-none"
          aria-label="Dismiss error"
        >
          ×
        </button>
      )}
    </div>
  );
}

/** Coloured status pill */
export function StatusBadge({ ready }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium
        ${ready
          ? "bg-emerald-100 text-emerald-700"
          : "bg-amber-100 text-amber-700"
        }`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${ready ? "bg-emerald-500" : "bg-amber-500"}`} />
      {ready ? "Models ready" : "Models not trained"}
    </span>
  );
}

/** Stat card used inside the results panel */
export function StatCard({ label, value, sub, accent = "indigo" }) {
  const colors = {
    indigo: "from-indigo-50 to-indigo-100 text-indigo-700 border-indigo-200",
    emerald: "from-emerald-50 to-emerald-100 text-emerald-700 border-emerald-200",
    amber: "from-amber-50 to-amber-100 text-amber-700 border-amber-200",
    slate: "from-slate-50 to-slate-100 text-slate-700 border-slate-200",
  };
  return (
    <div className={`bg-gradient-to-br ${colors[accent]} border rounded-xl p-4`}>
      <p className="text-xs font-medium uppercase tracking-wide opacity-70">{label}</p>
      <p className="text-2xl font-bold mt-1">{value}</p>
      {sub && <p className="text-xs opacity-60 mt-0.5">{sub}</p>}
    </div>
  );
}

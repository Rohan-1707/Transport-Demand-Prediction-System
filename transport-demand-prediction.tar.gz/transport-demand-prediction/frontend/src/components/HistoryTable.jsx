/**
 * components/HistoryTable.jsx
 * ----------------------------
 * Displays the last N predictions from the database.
 */

import { useEffect, useState } from "react";
import { getPredictionHistory } from "../services/api";
import { LoadingSpinner, ErrorAlert } from "./ui";

const LOCATION_LABELS = {
  downtown:      "Downtown",
  suburb:        "Suburb",
  airport:       "Airport",
  university:    "University",
  shopping_mall: "Mall",
};

function DemandPill({ value }) {
  const cls =
    value < 80  ? "bg-emerald-100 text-emerald-700" :
    value < 200 ? "bg-amber-100 text-amber-700"     :
                  "bg-red-100 text-red-700";
  return (
    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${cls}`}>
      {value}
    </span>
  );
}

export default function HistoryTable() {
  const [rows,      setRows]      = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error,     setError]     = useState(null);

  useEffect(() => {
    getPredictionHistory(10)
      .then(setRows)
      .catch((err) => setError(err.message))
      .finally(() => setIsLoading(false));
  }, []);

  if (isLoading) return <LoadingSpinner label="Loading history…" />;
  if (error)     return <ErrorAlert message={error} />;
  if (!rows.length)
    return (
      <p className="text-center text-slate-400 text-sm py-8">
        No predictions yet. Submit the form to get started!
      </p>
    );

  return (
    <div className="overflow-x-auto rounded-xl border border-slate-200">
      <table className="w-full text-sm text-left">
        <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
          <tr>
            {["Date", "Hour", "Location", "Weather", "Model", "Demand"].map((h) => (
              <th key={h} className="px-4 py-3 font-medium">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {rows.map((row) => (
            <tr key={row.id} className="hover:bg-slate-50 transition-colors">
              <td className="px-4 py-3 text-slate-700">{row.date}</td>
              <td className="px-4 py-3 text-slate-500">{row.hour}:00</td>
              <td className="px-4 py-3 text-slate-700 capitalize">
                {LOCATION_LABELS[row.location] || row.location}
              </td>
              <td className="px-4 py-3 text-slate-500 capitalize">{row.weather}</td>
              <td className="px-4 py-3 text-slate-500 capitalize">
                {row.model_used.replace(/_/g, " ")}
              </td>
              <td className="px-4 py-3">
                <DemandPill value={row.predicted_demand} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

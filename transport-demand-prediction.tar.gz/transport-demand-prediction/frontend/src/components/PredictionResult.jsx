/**
 * components/PredictionResult.jsx
 * --------------------------------
 * Displays the ML prediction with an animated demand gauge,
 * confidence interval bar, and input summary.
 */

import { useEffect, useState } from "react";
import { StatCard } from "./ui";

const DEMAND_MAX = 600; // upper bound for gauge

/** Animated circular gauge */
function DemandGauge({ value, max = DEMAND_MAX }) {
  const [displayed, setDisplayed] = useState(0);
  const radius  = 52;
  const circumference = 2 * Math.PI * radius;
  const pct     = Math.min(value / max, 1);
  const offset  = circumference * (1 - pct);

  // Animate counter up
  useEffect(() => {
    let start = 0;
    const step = value / 40;
    const id = setInterval(() => {
      start += step;
      if (start >= value) { setDisplayed(value); clearInterval(id); }
      else setDisplayed(Math.round(start));
    }, 20);
    return () => clearInterval(id);
  }, [value]);

  const color =
    pct < 0.33 ? "#10b981" :
    pct < 0.66 ? "#f59e0b" : "#ef4444";

  return (
    <div className="flex flex-col items-center gap-2">
      <svg width="140" height="140" viewBox="0 0 140 140">
        {/* Track */}
        <circle cx="70" cy="70" r={radius} fill="none"
          stroke="#e2e8f0" strokeWidth="10" />
        {/* Progress */}
        <circle cx="70" cy="70" r={radius} fill="none"
          stroke={color} strokeWidth="10"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transform: "rotate(-90deg)", transformOrigin: "70px 70px", transition: "stroke-dashoffset 0.8s ease" }}
        />
        <text x="70" y="66" textAnchor="middle" fontSize="26" fontWeight="700"
          fill={color} fontFamily="system-ui, sans-serif">
          {displayed}
        </text>
        <text x="70" y="84" textAnchor="middle" fontSize="10"
          fill="#94a3b8" fontFamily="system-ui, sans-serif">
          trips / hr
        </text>
      </svg>
      <p className="text-sm text-slate-500">Predicted demand</p>
    </div>
  );
}

/** Confidence interval visualisation */
function CIBar({ low, high, predicted, max = DEMAND_MAX }) {
  const pLow  = (low  / max) * 100;
  const pHigh = (high / max) * 100;
  const pMid  = (predicted / max) * 100;
  return (
    <div>
      <p className="text-xs text-slate-500 mb-2">Confidence interval</p>
      <div className="relative h-4 bg-slate-100 rounded-full overflow-visible">
        {/* CI range */}
        <div
          className="absolute top-0 h-full bg-indigo-200 rounded-full"
          style={{ left: `${pLow}%`, width: `${pHigh - pLow}%` }}
        />
        {/* Centre pin */}
        <div
          className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-indigo-600 rounded-full border-2 border-white shadow"
          style={{ left: `calc(${pMid}% - 6px)` }}
        />
      </div>
      <div className="flex justify-between text-xs text-slate-400 mt-1">
        <span>{low}</span>
        <span className="text-indigo-600 font-medium">{predicted}</span>
        <span>{high}</span>
      </div>
    </div>
  );
}

/** Demand level label */
function demandLabel(value) {
  if (value < 80)  return { label: "Low",    color: "text-emerald-600 bg-emerald-50" };
  if (value < 200) return { label: "Moderate", color: "text-amber-600 bg-amber-50" };
  return               { label: "High",   color: "text-red-600 bg-red-50" };
}

const LOCATION_LABELS = {
  downtown:      "Downtown",
  suburb:        "Suburb",
  airport:       "Airport",
  university:    "University",
  shopping_mall: "Shopping Mall",
};

const WEATHER_EMOJI = {
  sunny: "☀️", cloudy: "☁️", rainy: "🌧️", snowy: "❄️", windy: "💨",
};

export default function PredictionResult({ result }) {
  const { predicted_demand: demand, confidence_interval: ci,
          model_used, unit, input_summary } = result;
  const { label, color } = demandLabel(demand);
  const hour = input_summary.hour;
  const ampm = hour < 12 ? `${hour || 12} AM` : `${hour === 12 ? 12 : hour - 12} PM`;

  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-violet-600 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-indigo-200 text-xs font-medium uppercase tracking-wide">Prediction Result</p>
            <h2 className="text-white text-lg font-semibold mt-0.5">Transport Demand Forecast</h2>
          </div>
          <span className={`px-3 py-1 rounded-full text-sm font-semibold ${color}`}>
            {label}
          </span>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Gauge + CI */}
        <div className="flex flex-col sm:flex-row items-center gap-6">
          <DemandGauge value={demand} />
          <div className="flex-1 w-full space-y-4">
            <CIBar low={ci.low} high={ci.high} predicted={demand} />
            <div className="grid grid-cols-2 gap-3">
              <StatCard label="Lower bound" value={ci.low}  sub="trips / hr" accent="slate" />
              <StatCard label="Upper bound" value={ci.high} sub="trips / hr" accent="indigo" />
            </div>
          </div>
        </div>

        {/* Input summary */}
        <div className="border-t border-slate-100 pt-4">
          <p className="text-xs font-medium text-slate-400 uppercase tracking-wide mb-3">
            Inputs used
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
            {[
              { icon: "📅", label: "Date",     value: input_summary.date },
              { icon: "🕐", label: "Time",     value: ampm },
              { icon: "📍", label: "Location", value: LOCATION_LABELS[input_summary.location] },
              { icon: WEATHER_EMOJI[input_summary.weather] || "🌤️",
                             label: "Weather",   value: input_summary.weather },
            ].map(({ icon, label, value }) => (
              <div key={label} className="bg-slate-50 rounded-xl p-3">
                <p className="text-slate-400 text-xs">{icon} {label}</p>
                <p className="font-medium text-slate-700 capitalize mt-0.5">{value}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Model badge */}
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span className="w-2 h-2 rounded-full bg-violet-400" />
          Model: <span className="text-slate-600 font-medium capitalize">
            {model_used.replace(/_/g, " ")}
          </span>
          <span className="mx-1">·</span>
          {unit}
        </div>
      </div>
    </div>
  );
}

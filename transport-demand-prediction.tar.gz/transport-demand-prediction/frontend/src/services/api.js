/**
 * services/api.js
 * ---------------
 * Centralised API client for the Transport Demand backend.
 * All fetch calls live here — components stay clean.
 */

const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";

/** Generic fetch wrapper with error handling */
async function apiFetch(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json", ...options.headers },
    ...options,
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || `HTTP ${res.status}`);
  }

  return res.json();
}

/** POST /predict — returns demand prediction */
export async function predictDemand(payload) {
  return apiFetch("/predict", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

/** GET /health — returns API + model status */
export async function getHealth() {
  return apiFetch("/health");
}

/** POST /train — triggers model retraining */
export async function trainModels(params = {}) {
  return apiFetch("/train", {
    method: "POST",
    body: JSON.stringify(params),
  });
}

/** GET /predictions — returns recent prediction history */
export async function getPredictionHistory(limit = 10) {
  return apiFetch(`/predictions?limit=${limit}`);
}

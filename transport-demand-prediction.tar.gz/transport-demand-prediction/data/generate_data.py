"""
generate_data.py
----------------
Creates a synthetic transport demand dataset for training the ML model.
Demand is influenced by: hour, day of week, weather, location type, and season.
Run this once to produce transport_demand.csv.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

LOCATIONS = {
    "downtown":       {"base": 200, "peak_multiplier": 2.2},
    "suburb":         {"base": 80,  "peak_multiplier": 1.6},
    "airport":        {"base": 150, "peak_multiplier": 1.9},
    "university":     {"base": 120, "peak_multiplier": 2.0},
    "shopping_mall":  {"base": 100, "peak_multiplier": 1.8},
}

WEATHER_IMPACT = {
    "sunny":   1.0,
    "cloudy":  0.92,
    "rainy":   0.75,
    "snowy":   0.55,
    "windy":   0.85,
}

def peak_hour_multiplier(hour: int, is_weekend: bool) -> float:
    """Returns a demand multiplier based on hour of day."""
    if is_weekend:
        # Weekend: midday peak
        if 11 <= hour <= 15:
            return 1.6
        elif 18 <= hour <= 21:
            return 1.4
        elif 0 <= hour <= 6:
            return 0.3
        return 1.0
    else:
        # Weekday: morning + evening rush
        if 7 <= hour <= 9:
            return 1.9
        elif 17 <= hour <= 19:
            return 1.8
        elif 12 <= hour <= 13:
            return 1.3
        elif 0 <= hour <= 5:
            return 0.2
        return 1.0

def season_multiplier(month: int) -> float:
    """Returns demand multiplier based on month/season."""
    if month in [12, 1, 2]:    # Winter
        return 0.80
    elif month in [3, 4, 5]:   # Spring
        return 1.05
    elif month in [6, 7, 8]:   # Summer
        return 1.15
    else:                       # Autumn
        return 0.95

def generate_dataset(n_samples: int = 5000) -> pd.DataFrame:
    """Generates a synthetic transport demand DataFrame."""
    start_date = datetime(2023, 1, 1)
    end_date   = datetime(2024, 12, 31)
    date_range = (end_date - start_date).days

    records = []
    for _ in range(n_samples):
        # Random date + time
        rand_days  = np.random.randint(0, date_range)
        rand_hour  = np.random.randint(0, 24)
        date       = start_date + timedelta(days=rand_days)
        is_weekend = date.weekday() >= 5

        # Random location and weather
        location = np.random.choice(list(LOCATIONS.keys()))
        weather  = np.random.choice(
            list(WEATHER_IMPACT.keys()),
            p=[0.40, 0.25, 0.20, 0.08, 0.07]
        )

        # Compute demand with multiplicative factors + gaussian noise
        base_demand = LOCATIONS[location]["base"]
        peak_mult   = peak_hour_multiplier(rand_hour, is_weekend)
        loc_peak    = LOCATIONS[location]["peak_multiplier"] if peak_mult > 1.5 else 1.0
        weather_mult = WEATHER_IMPACT[weather]
        season_mult  = season_multiplier(date.month)
        noise        = np.random.normal(1.0, 0.08)          # ±8% noise

        demand = (
            base_demand * peak_mult * loc_peak
            * weather_mult * season_mult * noise
        )
        demand = max(5, round(demand))                       # floor at 5 trips

        records.append({
            "date":           date.strftime("%Y-%m-%d"),
            "hour":           rand_hour,
            "day_of_week":    date.weekday(),                # 0=Mon…6=Sun
            "month":          date.month,
            "is_weekend":     int(is_weekend),
            "location":       location,
            "weather":        weather,
            "temperature_c":  round(np.random.uniform(-5, 38), 1),
            "demand":         demand,
        })

    df = pd.DataFrame(records)
    return df

if __name__ == "__main__":
    import os
    out_path = os.path.join(os.path.dirname(__file__), "transport_demand.csv")
    df = generate_dataset(5000)
    df.to_csv(out_path, index=False)
    print(f"Dataset saved → {out_path}")
    print(df.describe())
    print(f"\nSample rows:\n{df.head()}")

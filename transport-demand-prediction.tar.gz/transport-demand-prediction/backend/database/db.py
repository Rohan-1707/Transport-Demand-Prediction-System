"""
database/db.py
--------------
Database setup using SQLAlchemy ORM with SQLite (swap URL for PostgreSQL).
Stores prediction history for auditing and analytics.
"""

import os
from datetime import datetime

from sqlalchemy import (
    Column, DateTime, Float, Integer, String,
    create_engine, text,
)
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

# ── Connection ──────────────────────────────────────────────────────────────
# To switch to PostgreSQL replace with:
#   DATABASE_URL = "postgresql://user:pass@localhost:5432/transport_db"
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "sqlite:///./transport_demand.db"
)

engine = create_engine(
    DATABASE_URL,
    # SQLite-specific: allows multi-thread access (needed for FastAPI)
    connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {},
    echo=False,
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


# ── ORM Base ────────────────────────────────────────────────────────────────

class Base(DeclarativeBase):
    pass


# ── Models ──────────────────────────────────────────────────────────────────

class PredictionLog(Base):
    """Stores each prediction request + result for history/analytics."""
    __tablename__ = "prediction_logs"

    id                = Column(Integer, primary_key=True, index=True)
    created_at        = Column(DateTime, default=datetime.utcnow)

    # Input fields
    input_date        = Column(String,  nullable=False)
    input_hour        = Column(Integer, nullable=False)
    input_location    = Column(String,  nullable=False)
    input_weather     = Column(String,  nullable=False)
    input_temperature = Column(Float,   nullable=True)
    model_used        = Column(String,  nullable=False)

    # Output fields
    predicted_demand  = Column(Integer, nullable=False)
    ci_low            = Column(Integer, nullable=False)
    ci_high           = Column(Integer, nullable=False)


# ── Helpers ─────────────────────────────────────────────────────────────────

def init_db() -> None:
    """Creates all tables if they don't exist yet."""
    Base.metadata.create_all(bind=engine)


def get_db():
    """
    FastAPI dependency: yields a DB session and closes it after the request.
    Usage:  db: Session = Depends(get_db)
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def log_prediction(db: Session, input_data: dict, result: dict) -> PredictionLog:
    """Persists a single prediction event to the database."""
    record = PredictionLog(
        input_date        = input_data.get("date", ""),
        input_hour        = input_data["hour"],
        input_location    = input_data["location"],
        input_weather     = input_data["weather"],
        input_temperature = input_data.get("temperature_c"),
        model_used        = result["model_used"],
        predicted_demand  = result["predicted_demand"],
        ci_low            = result["confidence_interval"]["low"],
        ci_high           = result["confidence_interval"]["high"],
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record

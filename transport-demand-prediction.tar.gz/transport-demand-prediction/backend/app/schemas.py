"""
app/schemas.py
--------------
Pydantic models for API request and response validation.
FastAPI uses these for automatic docs and input parsing.
"""

from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field, field_validator


class LocationEnum(str, Enum):
    downtown     = "downtown"
    suburb       = "suburb"
    airport      = "airport"
    university   = "university"
    shopping_mall = "shopping_mall"


class WeatherEnum(str, Enum):
    sunny  = "sunny"
    cloudy = "cloudy"
    rainy  = "rainy"
    snowy  = "snowy"
    windy  = "windy"


class ModelTypeEnum(str, Enum):
    random_forest     = "random_forest"
    linear_regression = "linear_regression"


# ── Request ────────────────────────────────────────────────────────────────

class PredictRequest(BaseModel):
    """Input payload for the /predict endpoint."""

    date: str = Field(
        ...,
        description="Date in YYYY-MM-DD format",
        examples=["2024-07-15"],
    )
    hour: int = Field(
        ...,
        ge=0, le=23,
        description="Hour of day (0–23)",
    )
    location: LocationEnum = Field(
        ...,
        description="Location type",
    )
    weather: WeatherEnum = Field(
        default=WeatherEnum.sunny,
        description="Weather condition",
    )
    temperature_c: Optional[float] = Field(
        default=20.0,
        ge=-20, le=50,
        description="Temperature in Celsius",
    )
    model_type: ModelTypeEnum = Field(
        default=ModelTypeEnum.random_forest,
        description="ML model to use",
    )

    @field_validator("date")
    @classmethod
    def validate_date(cls, v: str) -> str:
        from datetime import datetime
        try:
            datetime.strptime(v, "%Y-%m-%d")
        except ValueError:
            raise ValueError("date must be in YYYY-MM-DD format")
        return v


class TrainRequest(BaseModel):
    """Optional payload for the /train endpoint."""
    test_size: float = Field(default=0.2, ge=0.1, le=0.5)
    random_state: int = Field(default=42)


# ── Response ───────────────────────────────────────────────────────────────

class ConfidenceInterval(BaseModel):
    low:  int
    high: int


class PredictResponse(BaseModel):
    """Prediction result returned by /predict."""
    predicted_demand:     int
    confidence_interval:  ConfidenceInterval
    model_used:           str
    unit:                 str
    input_summary:        dict


class TrainResponse(BaseModel):
    """Training result returned by /train."""
    message: str
    metrics: dict


class HealthResponse(BaseModel):
    """API health check response."""
    status:       str
    models_ready: bool
    version:      str
